const getAppDataPath = require('appdata-path');
const sha1 = require('sha1-file');
const { v4: uuidv4 } = require('uuid');
const { Client, Authenticator } = require('minecraft-launcher-core');
const launcher = new Client();
var operatingSystem = require('os');
const axios = require('axios')

let playerUUID

const file = getDataPath(".minecraft/launcher_accounts.json")
let rawdata = fs.readFileSync(file);
let launcherThing = JSON.parse(rawdata);
playerUUID = Object.values(launcherThing.accounts)[0].minecraftProfile.id;

let quickconnectServer = null;
var updatedclienthash = null;

let priorityChecks = {
    launchStarted: false,
}

function setButtonState(state) {
    if (state == "running") {
        document.querySelector('.launch-button').classList.add('active');
    } else if (state == "down") {
        document.querySelector('.launch-button').classList.add('clicked');
    } else if (state == "up") {
        document.querySelector('.launch-button').classList.remove('clicked');
        document.querySelector('.launch-button').classList.add('launch-button');
    } else {
        document.querySelector('.launch-button').classList.remove('active');
        document.querySelector('.launch-button').classList.add('launch-button');
    }

}

async function getClientHash() {
    const response = await fetch('https://oldcheatbreaker.com/2018/update');
    const text = await response.text();

    updatedclienthash = text.replaceAll('\n', '');
    console.log("[CB] Got client hash: " + updatedclienthash);
}

function handleUpdates(test) {

    if (priorityChecks.launchStarted)  {
        return;
    }

    document.querySelector('#homebtn').classList.remove('active');
    document.querySelector('#serversbtn').classList.remove('active');
    document.querySelector('#settingsbtn').classList.remove('active');
    document.querySelector('#aboutbtn').classList.remove('active');

    priorityChecks.launchStarted = true;

    quickconnectServer = test;
    
    document.getElementById("home").style.display = "none";
    document.getElementById("servers").style.display = "none";
    document.getElementById("settings").style.display = "none";
    document.getElementById("about").style.display = "none";

    document.getElementById("launchloadbardiv").style.display = "block";
    document.querySelector(".launcherloadbartext").innerHTML = "Updating game assets...";
    console.log('[CB] Updating game assets...')
    getClientHash();

    setTimeout(function(){
        document.querySelector(".launcherloadbartext").innerHTML = "Updating to latest game files...";
        console.log('[CB] Updating to latest game files...')

        setTimeout(function() {
            document.querySelector(".launcherloadbartext").innerHTML = "Downloading latest game files...";
            console.log('[CB] Downloading latest game files...')
            document.querySelector('.launchload').style.width = "5%";
        setTimeout(function() {
            document.querySelector('.launchload').style.width = "8%";
        setTimeout(function() {
            document.querySelector('.launchload').style.width = "25%";
        setTimeout(function() {
            document.querySelector('.launchload').style.width = "26%";

        if (!fs.existsSync("C:\\Users\\" + operatingSystem.userInfo().username + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre.zip")) {
            document.querySelector(".launcherloadbartext").innerHTML = "Downloading JRE...";
            console.log('[CB] Downloading JRE...')
            downloadJRE("https://oldcheatbreaker.com/jre.zip", operatingSystem.userInfo().username);
        } else {
            continueLaunching();
        }

    }, 100);
    }, 200);
    }, 500);
    }, 500);
    }, 1000);
    
}

function continueLaunching() {
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "27%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "28%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "35%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "36%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "37%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "43%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "44%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "45%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "46%";  
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "47%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "48%";
    setTimeout(function() {
        document.querySelector('.launchload').style.width = "49%";
    setTimeout(function() {

    document.querySelector('.launchload').style.width = "55%";
    document.querySelector(".launcherloadbartext").innerHTML = "Checking game...";
    console.log('[CB] Checking game...');
    checkGame();

}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);
}, 100);

}

function openTab(evt, tabName) {

    if (priorityChecks.launchStarted) {
        return;
    }

    switch(tabName) {

        case 'home':
            document.querySelector('#homebtn').classList.add('active');
            document.querySelector('#serversbtn').classList.remove('active');
            document.querySelector('#settingsbtn').classList.remove('active');
            document.querySelector('#aboutbtn').classList.remove('active');
            break;

        case 'servers':
            document.querySelector('#homebtn').classList.remove('active');
            document.querySelector('#serversbtn').classList.add('active');
            document.querySelector('#settingsbtn').classList.remove('active');
            document.querySelector('#aboutbtn').classList.remove('active');
            break;

        case 'settings':
            document.querySelector('#homebtn').classList.remove('active');
            document.querySelector('#serversbtn').classList.remove('active');
            document.querySelector('#settingsbtn').classList.add('active');
            document.querySelector('#aboutbtn').classList.remove('active');
            break;

        case 'about':
            document.querySelector('#homebtn').classList.remove('active');
            document.querySelector('#serversbtn').classList.remove('active');
            document.querySelector('#settingsbtn').classList.remove('active');
            document.querySelector('#aboutbtn').classList.add('active');
            break;
    }

    var i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

function launchCheatBreakerNormal(update) {

    launcher.launch({ 
        clientPackage: update, 
        authorization: Authenticator.getAuth("CB-" + uuidv4()), 
        root: getAppDataPath('.minecraft'), 
        javaPath: "C:\\Users\\" + operatingSystem.userInfo().username + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre\\bin\\java.exe",
    version: { 
        number: "1.7.10", 
        custom: "CheatBreakerRemastered" 
    },
    memory: { max:  document.getElementById("ram-slider-id").value, min: "1024" }}).catch(e => {
        console.log(e);
    });

    launcher.on('data', (e) => {
        document.querySelector('.launchload').style.width = "100%";
        document.querySelector(".launcherloadbartext").innerHTML = "Game running...";
        hideLauncher();

        console.log(e);
    })

    launcher.on('debug', (e) => {
        var launcherlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/launcher.log'), {
          flags: 'a'
        })
        
        launcherlogs.write(e)
    })
      
    launcher.on('data', (e) => {        
        document.querySelector('.launchload').style.width = "100%";
        document.querySelector(".launcherloadbartext").innerHTML = "Game running...";
        hideLauncher();
      
      var clientlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/client.log'), {
        flags: 'a'
      })
      
      clientlogs.write(e)
    })

    launcher.on('error', (e) => {        
      var errorlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/global_errors.log'), {
        flags: 'a'
      })
      
      errorlogs.write(e)
    })

    launcher.on('close', (e) => {
        document.querySelector('.launchload').style.width = "0%";
        document.querySelector(".launcherloadbartext").innerHTML = "";
            var window = remote.getCurrentWindow();
            window.show();
            document.querySelector('#homebtn').classList.add('active');
            document.querySelector('#serversbtn').classList.remove('active');
            document.querySelector('#settingsbtn').classList.remove('active');
            document.querySelector('#aboutbtn').classList.remove('active');

            document.getElementById("home").style.display = "block";
            document.getElementById("servers").style.display = "none";
            document.getElementById("settings").style.display = "none";
            document.getElementById("about").style.display = "none";
        
            document.querySelector('.launchload').style.width = "0%";
            document.getElementById("launchloadbardiv").style.display = "none";
            document.querySelector(".launcherloadbartext").innerHTML = "";
            setButtonState("start");
            priorityChecks.launchStarted = false;
    })
    
}

function launchCheatBreaker(update, server) {
    console.log("launch: " + server);

    launcher.launch({ clientPackage: update, authorization: Authenticator.getAuth("CB-" + uuidv4()), root: getAppDataPath('.minecraft'), 
    javaPath: "C:\\Users\\" + operatingSystem.userInfo().username + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre\\bin\\java.exe",
    version: { 
        number: "1.7.10", 
        custom: "CheatBreakerRemastered" 
    },
    server: {
        host: server,
        port: 25565
    },
    memory: { max:  document.getElementById("ram-slider-id").value, min: "1024" }});

    launcher.on('debug', (e) => {
        var launcherlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/launcher.log'), {
          flags: 'a'
        })
        
        launcherlogs.write(e)
    })
      
    launcher.on('data', (e) => {        
        document.querySelector('.launchload').style.width = "100%";
        document.querySelector(".launcherloadbartext").innerHTML = "Game running...";
        hideLauncher();
      
      var clientlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/client.log'), {
        flags: 'a'
      })
      
      clientlogs.write(e)
    })

    launcher.on('error', (e) => {        
        var errorlogs = fs.createWriteStream(getAppDataPath('.minecraft/CheatBreakerRemastered/logs/global_errors.log'), {
          flags: 'a'
        })
        
        errorlogs.write(e)
    })

    launcher.on('close', (e) => {
        document.querySelector('.launchload').style.width = "0%";
        document.querySelector(".launcherloadbartext").innerHTML = "";
            var window = remote.getCurrentWindow();
            window.show();
            document.querySelector('#homebtn').classList.add('active');
            document.querySelector('#serversbtn').classList.remove('active');
            document.querySelector('#settingsbtn').classList.remove('active');
            document.querySelector('#aboutbtn').classList.remove('active');
            
            document.getElementById("home").style.display = "block";
            document.getElementById("servers").style.display = "none";
            document.getElementById("settings").style.display = "none";
            document.getElementById("about").style.display = "none";
        
            document.querySelector('.launchload').style.width = "0%";
            document.getElementById("launchloadbardiv").style.display = "none";
            document.querySelector(".launcherloadbartext").innerHTML = "";
            setButtonState("start");
            priorityChecks.launchStarted = false;
    })
    
}

function checkGame() {

    fs.readFile(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'), function (err, data) {
        if (err) throw err;

        if (data.indexOf('1.8') >= 1) {

            console.log("[CB] Tried to launch, couldn't get a pool from the resource, assuming its an unavailable version.");

            alert('CheatBreaker 1.8 is currently not available, please try again later.');
            document.getElementById("home").style.display = "block";
            document.getElementById("servers").style.display = "none";
            document.getElementById("settings").style.display = "none";
            document.getElementById("about").style.display = "none";
        
            document.querySelector('.launchload').style.width = "0%";
            document.getElementById("launchloadbardiv").style.display = "none";
            document.querySelector(".launcherloadbartext").innerHTML = "";
            setButtonState("start");
            priorityChecks.launchStarted = false;
            return;
        }

            if (!fs.existsSync(getAppDataPath('.minecraft\\versions\\CheatBreakerRemastered\\CheatBreakerRemastered.jar'))) {
                document.querySelector('.launchload').style.width = "85%";
                document.querySelector(".launcherloadbartext").innerHTML = "Downloading & updating game...";
                setButtonState("running");
                console.log('[CB] Client Update Found! Updating game...');
        
                if (quickconnectServer == "pvp.bar" || quickconnectServer == "mine.rip" || quickconnectServer == "kirah.cf" || quickconnectServer == "glacial.cc") {
                    launchCheatBreaker("https://files.oldcheatbreaker.com/CheatBreaker.zip", quickconnectServer);
                } else {
                    launchCheatBreakerNormal("https://files.oldcheatbreaker.com/CheatBreaker.zip");
                }
        
            } else {
                var currentclienthash = sha1.sync(getAppDataPath('.minecraft\\versions\\CheatBreakerRemastered\\CheatBreakerRemastered.jar'));
        
                if (currentclienthash == updatedclienthash) {
                    document.querySelector('.launchload').style.width = "85%";
                    document.querySelector(".launcherloadbartext").innerHTML = "Launching game...";
                    setButtonState("running");
                    console.log('[CB] Launching game...');
        
                    if (quickconnectServer == "pvp.bar" || quickconnectServer == "kirah.cf" || quickconnectServer == "mine.rip" || quickconnectServer == "glacial.cc") {
                        launchCheatBreaker(null, quickconnectServer);
                    } else {
                        launchCheatBreakerNormal(null);
                    }
            
                    setTimeout(function() {
                        document.querySelector('.launchload').style.width = "100%";
                        document.querySelector(".launcherloadbartext").innerHTML = "Game running...";
                        setButtonState("running");
                        console.log('[CB] Game running...');
                    }, 1000);
            
                } else {
                    document.querySelector('.launchload').style.width = "85%";
                    document.querySelector(".launcherloadbartext").innerHTML = "Downloading & updating game...";
                    setButtonState("running");
                    console.log('[CB] Client Update Found! Updating game...');
        
                    if (quickconnectServer == "pvp.bar" || quickconnectServer == "kirah.cf" || quickconnectServer == "mine.rip") {
                        launchCheatBreaker("https://files.oldcheatbreaker.com/CheatBreaker.zip", quickconnectServer);
                    } else {
                        launchCheatBreakerNormal("https://files.oldcheatbreaker.com/CheatBreaker.zip");
                    }
        
                }
            }
    });


}