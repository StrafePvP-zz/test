var authMessage = null;

let authUrl = 'https://oldcheatbreaker.com/2018/1.7.json';

fetch(authUrl)
    .then(news => news.json())
    .then((response) => {
        authMessage = response.allowed;
        console.log("[CB] Received Authentication Message: " + authMessage);
    }).catch(err => {
        throw err
    });