const { app } = require('electron').remote;
const fs = require('fs');

function jreDownload() {
document.querySelector('.splashprogress').style.width = "0%";

setTimeout(function(){
    document.querySelector('.status-text').innerHTML = "Checking latest version information...";
    console.log('[CB] Checking latest version information...')
    document.querySelector('.splashprogress').style.width = "20%";
        setTimeout(function(){
        document.querySelector('.status-text').innerHTML = "Downloading JRE...";
        console.log('[CB] Downloading JRE...')
        document.querySelector('.splashprogress').style.width = "40%";
            setTimeout(function(){
            document.querySelector('.splashprogress').style.width = "70%";
                setTimeout(function(){
                    document.querySelector('.splashprogress').style.width = "100%";
                    console.log('[CB] Starting CheatBreaker...')
                        // loadMain();
                }, 100);
            }, 100);
        }, 100);
    }, 100);
}