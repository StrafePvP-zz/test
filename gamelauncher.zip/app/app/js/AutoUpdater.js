const download = require('download');
const hashCheck = require('sha1-file');
const DecompressZip = require('decompress-zip');
const rimraf = require("rimraf");

var updatedLauncherHash = null;

function checkForUpdates(user) {
    getLauncherHash();

    if (!fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip") 
    && fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\app")) {
        downloadLauncherUpdate("https://files.oldcheatbreaker.com/gamelauncher.zip", user);
    } else if (fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip") 
    && !fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\app")) {
        extractUpdate(user);
    }


    var currentLauncherHash = hashCheck.sync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip");

    if (!currentLauncherHash == updatedLauncherHash) {
        console.log("[CB] Launcher Update found! Downloading update...");
        downloadLauncherUpdate("https://files.oldcheatbreaker.com/gamelauncher.zip", user);
    } else {
        console.log("[CB] No launcher updates were found...");
    }

}

async function updateChecks(user) {

    if (fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip") && fs.existsSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\app\\")) {
        rimraf("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\app\\", function () { 
            console.log("[CB] Removing last update..."); });
    } else {
        Promise.delay(5000).then(() => updateChecks());
    }

}

async function downloadJRE(link, user) {

    // JRE Downloading
    fs.writeFileSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre.zip", await download(link));
    download(link).pipe(fs.createWriteStream("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre.zip"));

    // JRE Extracting

    setTimeout(function() {
    
        var unzipper = new DecompressZip("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\jre.zip")
    
        unzipper.on('error', function (err) {
            console.log(err);
            alert('There was a problem extracting the JRE, contact an admin.')
        });
        
        unzipper.on('extract', function (log) {
            console.log('[CB] Extracted JRE...');
            continueLaunching();
        });
        
        unzipper.extract({
            path: "C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\",
            filter: function (file) {
                return file.type !== "SymbolicLink";
            }
        });
    
    }, 15000);
    
}

function extractUpdate(user) {
    var unzipper = new DecompressZip("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip")
    
    unzipper.on('error', function (err) {
        console.log(err);
    });
    
    unzipper.on('extract', function (log) {
        console.log('[CB] Extracted Update, probably just their PC being weird...');
    });
    
    unzipper.extract({
        path: "C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\",
        filter: function (file) {
            return file.type !== "SymbolicLink";
        }
    });
}

async function downloadLauncherUpdate(link, user) {

    // Downloading
    fs.writeFileSync("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip", await download(link));
    download(link).pipe(fs.createWriteStream("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip"));

    // Removes old update
    updateChecks(user);

    // Extracting

    setTimeout(function() {
    
        var unzipper = new DecompressZip("C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\gamelauncher.zip")
    
        unzipper.on('error', function (err) {
            console.log(err);
        });
        
        unzipper.on('extract', function (log) {
            console.log('[CB] Extracted Update...');
            alert("A launcher update has been downloaded, restart CheatBreaker to apply it. Failure to do so may cause bugs in the future.");
        });
        
        unzipper.extract({
            path: "C:\\Users\\" + user + "\\AppData\\Local\\Programs\\CheatBreaker Remastered\\resources\\",
            filter: function (file) {
                return file.type !== "SymbolicLink";
            }
        });
    
    }, 2000);
    
}

async function getLauncherHash() {
    const response = await fetch('https://oldcheatbreaker.com/2018/launcher/update');
    const text = await response.text();

    updatedLauncherHash = text.replaceAll('\n', '');
    console.log("[CB] Got launcher hash: " + updatedLauncherHash);
}