const remote = require('electron').remote;

function accountList() {
  document.getElementById("main-page").style.display = "none";
  document.getElementById("account-page").style.display = "block";
}

function loginPage() {
  document.getElementById("login-page").style.display = "block";
  document.getElementById("account-page").style.display = "none";
}

function returnFromLogin() {
  document.getElementById("main-page").style.display = "block";
  document.getElementById("login-page").style.display = "none";
  document.getElementById("account-page").style.display = "none";
}

function closeLauncher() {
  var window = remote.getCurrentWindow();
  window.close();
}

function minimizeLauncher() {
  var window = remote.getCurrentWindow();
  window.minimize();
}

function hideLauncher() {
  var window = remote.getCurrentWindow();
  window.hide();
}

function showLauncher() {
  var window = remote.getCurrentWindow();
  window.show();
}

document.addEventListener("keydown", e => {
  if(e.key == "F11") e.preventDefault();
});

document.addEventListener("keydown", e => {
  if(e.key == "SHIFT") e.preventDefault();
});

document.addEventListener("keydown", e => {
  if(e.ctrlKey) e.preventDefault();
});