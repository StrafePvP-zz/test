const { default: getDataPath } = require('appdata-path');
const { ALL } = require('dns');
var os = require('os');
let Username
let PlayerUUID

if (fs.existsSync(getDataPath('.minecraft/CheatBreakerRemastered/'))) {
    let ramdata = fs.readFileSync(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'));
    var ram = JSON.parse(ramdata);
}

function loadSettings() {

    if (!fs.existsSync(getDataPath('.minecraft/CheatBreakerRemastered'))) {
        fs.mkdirSync(getDataPath('.minecraft/CheatBreakerRemastered'))
    }

    if (!fs.existsSync(getDataPath('.minecraft/CheatBreakerRemastered/logs'))) {
        fs.mkdirSync(getDataPath('.minecraft/CheatBreakerRemastered/logs'));
    }
    
    if (!fs.existsSync(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'))) {
        fs.appendFile(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'), '{"memory":"1536", "version":"1.7"}', function (err) {
            if (err) throw err;
            alert("We notice this is your first time using CheatBreaker, to ensure a bug-free experience, please log out and back in through the Minecraft Launcher.");
          });
    }

    let ramdata2 = fs.readFileSync(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'));
    var ram2 = JSON.parse(ramdata2);
    document.querySelector(".ramslider-value").innerHTML = ram2.memory + " MB";
    document.getElementById("ram-slider-id").value = ram2.memory;

    document.querySelector('#homebtn').classList.add('active');

    if (!fs.existsSync(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'))) {
        fs.mkdirSync(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'));
    }

    fs.readFile(getDataPath('.minecraft/CheatBreakerRemastered/CheatBreakerLauncherSettings.json'), function (err, data) {
        if (err) throw err;

        if (data.indexOf('1.8') >= 1) {
            updateSettings5();
        }

        if(data.indexOf('1.7') >= 1){
            updateSettings4();
        }
    });

}

document.querySelector('.memoryvalue').innerHTML = (parseFloat(os.totalmem()) / 1048576).toFixed(0) + " MB";
document.querySelector('.cpuvalue').innerHTML = os.cpus()[0]['model'] + " (" + os.arch() + " architecture)";

loadpvpbarPlayers();
loadAccounts();

function loadAccounts() {

    const file = getDataPath(".minecraft/launcher_accounts.json")
    let rawdata = fs.readFileSync(file);
    let launcherThing = JSON.parse(rawdata);

    var accountNumber = 0;


    try {
        Username = Object.values(launcherThing.accounts)[accountNumber].minecraftProfile.name;
        PlayerUUID = Object.values(launcherThing.accounts)[accountNumber].minecraftProfile.id;

        switch (Object.values(launcherThing.accounts).length) {

            case 1:
                document.getElementById('accounts-list').innerHTML = '<div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '</p></div>'
                break;

            case 2:
                document.getElementById('accounts-list').innerHTML = '<div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '</p></div>'
                break;

            case 3:
                document.getElementById('accounts-list').innerHTML = '<div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '</p></div>'
                break;

            case 4:
                document.getElementById('accounts-list').innerHTML = '<div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '</p></div>  <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[3].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[3].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[4].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[4].minecraftProfile.name + '</p></div>'
                break;

            case 5:
                document.getElementById('accounts-list').innerHTML = '<div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[0].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[1].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[2].minecraftProfile.name + '</p></div>  <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[3].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[3].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[4].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[4].minecraftProfile.name + '</p></div> <div class="button-space"></div> <div class="account-box"><img class="account-head" draggable="false" src="https://minotar.net/helm/' + Object.values(launcherThing.accounts)[5].minecraftProfile.name + '/24"><p class="account-page-displayname">' + Object.values(launcherThing.accounts)[5].minecraftProfile.name + '</p></div>'
                break;

        }

        
        console.log(Object.values(launcherThing.accounts).length);
        document.querySelector('.account-switcher-displayname').innerHTML = Username;
        document.querySelector('.account-switcher-avatar').src = "https://visage.surgeplay.com/face/" + PlayerUUID;

    } catch (e) { }

    checkForUpdates(os.userInfo().username);
}

async function loadpvpbarPlayers() {
    const resp = await fetch('https://api.mcsrvstat.us/2/pvp.bar')
    const json = await resp.json()
    const onlinePlayers = json.players.online;

    if (onlinePlayers.length > 1) {
        document.querySelector('.pvpbar-online').style.marginLeft = "395px";
    }

    document.querySelector('.pvpbar-online').innerHTML = onlinePlayers + " ONLINE";
}

function updateSettings1() {

    document.getElementById('option1').style.backgroundColor = "#DD4455";
    document.getElementById('option2').style.backgroundColor = "#F2F2F2";
    document.getElementById('option3').style.backgroundColor = "#F2F2F2";

    document.getElementById('option1').style.color = "white";
    document.getElementById('option2').style.color = "#A7A7A7";
    document.getElementById('option3').style.color = "#A7A7A7";

}

function updateSettings2() {

    document.getElementById('option1').style.backgroundColor = "#F2F2F2";
    document.getElementById('option2').style.backgroundColor = "#DD4455";
    document.getElementById('option3').style.backgroundColor = "#F2F2F2";

    document.getElementById('option1').style.color = "#A7A7A7";
    document.getElementById('option2').style.color = "white";
    document.getElementById('option3').style.color = "#A7A7A7";

}

function updateSettings3() {

    document.getElementById('option1').style.backgroundColor = "#F2F2F2";
    document.getElementById('option2').style.backgroundColor = "#F2F2F2";
    document.getElementById('option3').style.backgroundColor = "#DD4455";

    document.getElementById('option1').style.color = "#A7A7A7";
    document.getElementById('option2').style.color = "#A7A7A7";
    document.getElementById('option3').style.color = "white";

}

function updateSettings4() {

    document.getElementById('option5').style.backgroundColor = "#F2F2F2";
    document.getElementById('option4').style.backgroundColor = "#DD4455";

    document.getElementById('option5').style.color = "#A7A7A7";
    document.getElementById('option4').style.color = "white";

    let versionData1 = {"memory":"" + ram.memory + "", "version":"" + "1.7" + ""};

    let data4 = JSON.stringify(versionData1);
    fs.writeFileSync(getDataPath('.minecraft') + '/CheatBreakerRemastered/CheatBreakerLauncherSettings.json', data4);

}

function updateSettings5() {

    

    document.getElementById('option4').style.backgroundColor = "#F2F2F2";
    document.getElementById('option5').style.backgroundColor = "#DD4455";

    document.getElementById('option4').style.color = "#A7A7A7";
    document.getElementById('option5').style.color = "white";

    let versionData2 = {"memory":"" + ram.memory + "", "version":"" + "1.8" + ""};

    let data5 = JSON.stringify(versionData2);
    fs.writeFileSync(getDataPath('.minecraft') + '/CheatBreakerRemastered/CheatBreakerLauncherSettings.json', data5);

}