console.log('[CB] Received websocket response');

let url = 'https://oldcheatbreaker.com/2018/news.json';

fetch(url)
    .then(news => news.json())
    .then((response) => {
        document.querySelector('.newstitle').innerHTML = response.title;
        document.querySelector('.newsavatar').src = response.icon;
        document.querySelector('.newsauthor').innerHTML = response.author;
        document.querySelector('.newsdate').innerHTML = response.date;
        document.querySelector('.newspost').innerHTML = response.content;
    })
    .catch(err => {
        throw err
    });