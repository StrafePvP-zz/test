const { app, BrowserWindow } = require('electron');

let jrewindow
let eulawindow

app.on('ready', () => {
	loadWindow()
});

const loadWindow = () => {
  mainWindow = new BrowserWindow({
	  title: "CheatBreaker",
	  titleBarStyle: 'hidden',
	  icon: 'app/img/icon.ico',
	  width: 1152,
	  height: 648,
	  webPreferences: {
		  nodeIntegration: true,
		  enableRemoteModule: true
	  },
	  center: true,
	  maximizable: false,
	  frame: false,
	  show: false,
	  resizable: false,
	  transparent: true,
	  fullscreen: false,
      show: false
  });
  jrewindow = new BrowserWindow({width: 1152, height: 648, icon: 'app/img/icon.ico', transparent: true, frame: false, alwaysOnTop: true});
  	jrewindow.loadURL(`file://${__dirname}/app/jre.html`);
	mainWindow.loadURL(`file://${__dirname}/app/index.html`);

	// app.on('jreSuccess', () => {
		jrewindow.destroy();
		mainWindow.show();
	// });

  mainWindow.webContents.on('did-finish-load', () => { 
    mainWindow.webContents.session.clearCache(function(){
        console.error('Cache Cleared')
    });
});

};