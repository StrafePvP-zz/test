const builder = require('electron-builder')
const Platform = builder.Platform

function getCurrentPlatform(){
    switch(process.platform){
        case 'win32':
            return Platform.WINDOWS
        case 'darwin':
            return Platform.MAC
        case 'linux':
            return Platform.linux
        default:
            console.error('Cannot resolve current platform!')
            return undefined
    }
}

builder.build({
    targets: getCurrentPlatform().createTarget(),
    config: {
        appId: 'CheatBreaker Remastered',
        productName: 'CheatBreaker Remastered',
        artifactName: 'CheatBreakerInstall.${ext}',
        copyright: 'CheatBreaker Remastered Development Team',
        directories: {
            buildResources: 'build',
            output: 'dist'
        },
        win: {
            target: [
                {
                    target: 'nsis',
                    arch: 'x64'
                }
            ]
        },
        nsis: {
            oneClick: false,
            perMachine: false,
            allowElevation: true,
            allowToChangeInstallationDirectory: true
        },
        mac: {
            target: 'dmg',
            category: 'public.app-category.games'
        },
        linux: {
            target: 'AppImage',
            maintainer: 'CheatBreaker Remastered Development Team',
            vendor: 'CheatBreaker Remastered Development Team',
            synopsis: 'CheatBreaker Remastered',
            description: 'CheatBreaker Remastered is the #1 free modpack and client-side anticheat built for Minecraft 1.7.10.',
            category: 'Game'
        },
        compression: 'maximum',
        files: [
            '!{dist,.gitignore,.vscode,docs,dev-app-update.yml,.travis.yml,.nvmrc,.eslintrc.json,pack.js}'
        ],
        extraResources: [
            'libraries'
        ],
        asar: false
    }
}).then(() => {
    console.log('Build complete!')
}).catch(err => {
    console.error('Error during build!', err)
})